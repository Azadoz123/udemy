﻿namespace NLayer.Core.DTOs
{
    public class CategoryDto : BaseDto
    {
        public string Name { get; set; }
    }
}
