﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    //IEntity implement eden class bir veritabanı tablosudur
    public interface IEntity
    {
    }
}
