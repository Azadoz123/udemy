﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.CCS
{
    public interface ILogger
    {
        void Log();
    }
}
